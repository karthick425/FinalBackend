﻿using StockExchangeService.Models;

namespace StockExchangeService.Services
{
    public interface ICompanyService
    {
        List<Company> Get();
        Company Get(string compid);
        Company Create(Company company);
        void Remove(string companycode);
    }
}
