﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using StockExchangeService.Models;

namespace StockExchangeService.Services
{
    public class CompanyService: ICompanyService
    {
        private readonly IMongoCollection<Company> _companys;

        public CompanyService(ICompanyStoreDatabaseSettings settings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(settings.DatabaseName);
            _companys = database.GetCollection<Company>(settings.CompanyCollectionName);
        }

        //public Company Create(Company company)
        //{
        //    _companys.InsertOne(company);
        //    return company;
        //}

        public List<Company> Get()
        {
            return _companys.Find(company => true).ToList();
        }
        public Company Get(string companycode)
        {
            return _companys.Find(company => company.CompanyCode == companycode).FirstOrDefault();
        }
        public Company Create(Company company)
        {
            _companys.InsertOne(company);
            return company;
        }

        public void Remove(string companycode)
        {
            _companys.DeleteOne(company => company.CompanyCode == companycode);
        }

    }
}
