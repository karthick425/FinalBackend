﻿using StockExchangeService.Models;

namespace StockExchangeService.Services
{
    public interface IStockService
    {
        List<Stock> Get(string compid, DateTime startDate, DateTime endDate);
        List<Stock> Get(string compid);
        Stock Insert(Stock stock);
        void Remove(string companycode);
    }
}
