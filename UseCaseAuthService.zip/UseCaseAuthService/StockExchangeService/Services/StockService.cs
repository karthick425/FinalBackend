﻿using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using StockExchangeService.Models;

namespace StockExchangeService.Services
{
    public class StockService : IStockService
    {
        private readonly IMongoCollection<Stock> _stockdetails;

        public StockService(IStockStoreDatabaseSettings settings, IMongoClient mongoClient)
        {
            var database = mongoClient.GetDatabase(settings.DatabaseName);
            _stockdetails = database.GetCollection<Stock>(settings.StockCollectionName);
        }

        public List<Stock> Get(string companycode, DateTime startDate, DateTime endDate)
        {
            var stockDetails= _stockdetails.Find(x => x.CompanyCode == companycode).ToList();
            return stockDetails.Where(x => x.CompanyCode == companycode && x.StockDate.Date<= endDate && x.StockDate.Date >= startDate).ToList();
        }
        public List<Stock> Get(string companycode)
        {
            return _stockdetails.Find(x => x.CompanyCode == companycode).ToList();
        }
        public Stock Insert(Stock stock)
        {
            _stockdetails.InsertOne(stock);
            return stock;
        }

        public void Remove(string companycode)
        {
            _stockdetails.DeleteMany(company => company.CompanyCode == companycode);
        }

    }
}

