﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using MongoDB.Driver;
using StockExchangeService.Models;
using StockExchangeService.Services;
using System.Text.Json.Serialization;

namespace StockExchangeService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class StockController : ControllerBase
    {
        private readonly IStockService stockService;
        private readonly ICompanyService companyService;

        public StockController(IStockService stockService,ICompanyService companyService)
        {
            this.stockService = stockService;
            this.companyService = companyService;
        }

        // GET api/<StudentsController>/5
        [HttpGet("{id}/{startDate}/{endDate}")]
        public ActionResult<List<Stock>> Get([System.Web.Http.FromUri] string id,DateTime startDate,DateTime endDate)
        {
            var StockList = stockService.Get(id, startDate, endDate);

            if (StockList == null)
            {
                return NotFound($"Company with Id = {id} not found");
            }

            return StockList;
        }
        [HttpPost]
        public ActionResult<Stock> Post([FromBody] Stock stock)
        {
            var companyDetails = companyService.Get(stock.CompanyCode);

            if (companyDetails == null)
            {
                return BadRequest($"Company Code does not exists");
            }
            stockService.Insert(stock);

            return CreatedAtAction(nameof(Get), new { id = stock.Id }, stock);
        }
        // DELETE api/<StudentsController>/5
        //[HttpDelete("{id}")]
        //public ActionResult Delete(string id)
        //{
        //    var Stocks = stockService.Get(id);

        //    if (Stocks == null)
        //    {
        //        return NotFound($"Company with Id = {id} not found");
        //    }

        //    stockService.Remove(id);

        //    return Ok($"Stock with Id = {id} deleted");
        //}
    }
}
