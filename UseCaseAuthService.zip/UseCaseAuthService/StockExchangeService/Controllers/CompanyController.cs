﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using StockExchangeService.Models;
using StockExchangeService.Services;

namespace StockExchangeService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    [Authorize]
    public class CompanyController : ControllerBase
    {
        private readonly ICompanyService companyService;
        private readonly IStockService stockService;

        public CompanyController(ICompanyService companyService, IStockService stockService)
        {
            this.companyService = companyService;
            this.stockService = stockService;
        }
        // GET: api/<StudentsController>
        [HttpGet]
        public ActionResult<List<Company>> Get()
        {
            return companyService.Get();
        }

        // GET api/<StudentsController>/5
        [HttpGet("{id}")]
        public ActionResult<Company> Get(string id)
        {
            var student = companyService.Get(id);

            if (student == null)
            {
                return NotFound($"Company with Id = {id} not found");
            }

            return student;
        }
        [HttpPost]
        public ActionResult<Company> Post([FromBody] Company company)
        {
            var companyDetails = companyService.Get(company.CompanyCode);

            if (companyDetails != null)
            {
                return BadRequest($"Company Code {company.CompanyCode} already exists");
            }
            if (company.TurnOver< 100000000 )
            {
                return BadRequest($"Company turnOver  must be greater than 10 cr");
            }
            companyService.Create(company);

            return CreatedAtAction(nameof(Get), new { id = company.Id }, company);
        }
        // DELETE api/<StudentsController>/5
        [HttpDelete("{id}")]
        public ActionResult Delete(string id)
        {
            var company = companyService.Get(id);

            if (company == null)
            {
                return NotFound($"Company with Id = {id} not found");
            }

            companyService.Remove(company.CompanyCode);
            stockService.Remove(company.CompanyCode);
            return Ok($"Company with Id = {id} deleted");
        }
    }
}