﻿namespace StockExchangeService.Models
{
    public class StockStoreDatabaseSettings: IStockStoreDatabaseSettings
    {
        public string StockCollectionName { get; set; } = String.Empty;
        public string ConnectionString { get; set; } = String.Empty;
        public string DatabaseName { get; set; } = String.Empty;
    }
}
