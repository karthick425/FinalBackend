﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System.Runtime.Serialization;
using System.Text.Json.Serialization;

namespace StockExchangeService.Models
{
    [BsonIgnoreExtraElements]
    public class Stock
    {
        [BsonId]
        [JsonIgnore]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; } = String.Empty;

        [BsonElement("CompanyCode")]
        public string CompanyCode { get; set; } = String.Empty;
        [BsonElement("StockPrice")]       
        public double StockPrice { get; set; } = default(double);
        [BsonElement("StockDate")]    
        public DateTime StockDate { get; set; } = DateTime.Now;
        [BsonElement("CreatedDate")]
        [JsonIgnore]
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}

