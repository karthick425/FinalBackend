﻿namespace StockExchangeService.Models
{
    public interface ICompanyStoreDatabaseSettings
    {
        string CompanyCollectionName { get; set; }
        string ConnectionString { get; set; }
        string DatabaseName { get; set; }
    }
}
