﻿using MongoDB.Bson.Serialization.Attributes;
using MongoDB.Bson;
using System.Text.Json.Serialization;

namespace StockExchangeService.Models
{
    [BsonIgnoreExtraElements]
    public class Company
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        [JsonIgnore]
        public string Id { get; set; } = String.Empty;

        [BsonElement("CompanyCode")]
        public string CompanyCode { get; set; } = String.Empty;
        [BsonElement("CompanyName")]
        public string CompanyName { get; set; } = String.Empty;
        [BsonElement("CompanyCEO")]
        public string CEO { get; set; } = String.Empty;
        [BsonElement("CompanyTurnOver")]
        public decimal TurnOver { get; set; }
        [BsonElement("CompanyWebsite")]
        public string Website { get; set; } = String.Empty;

        [BsonElement("StockExchangeListed")]
        public string StockExchangeListed { get; set; } = String.Empty;
        [BsonElement("CreatedDate")]
        [JsonIgnore]
        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
